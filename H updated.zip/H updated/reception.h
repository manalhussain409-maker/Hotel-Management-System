#ifndef RECEPTION_H
#define RECEPTION_H
void receptionMenu();
#endif
