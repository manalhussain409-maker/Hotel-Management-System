#include "hotel.h"

int main() {
    HotelSystem system;
    system.run();
    return 0;
}
