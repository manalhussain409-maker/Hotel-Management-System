#include "hotel.h"
#include "sqlite3ext.h"
#include "sqlite3.h"

// ---------- Small internal helper for prepared statements ----------
static bool stepDone(sqlite3* db, sqlite3_stmt* st) {
    int rc = sqlite3_step(st);
    if (rc != SQLITE_DONE) {
        cerr << "SQLite step error: " << sqlite3_errmsg(db) << "\n";
        return false;
    }
    return true;
}

HotelSystem::HotelSystem() {
    // fixed menu data (not stored in DB)
    carTypes_ = {
        {"Suzuki Alto", 3500},
        {"Suzuki Wagon R", 5000},
        {"Toyota Corolla", 6500},
        {"Honda Civic", 8500},
        {"Mercedes C-Class", 20000}
    };

    dishes_ = {
        {"Chicken Biryani", 450},
        {"Beef Karahi", 1200},
        {"Chicken Handi", 1100},
        {"BBQ Platter", 1600},
        {"Zinger Burger", 550},
        {"Chicken Shawarma", 350},
        {"Fried Fish", 900},
        {"Pasta Alfredo", 800},
        {"Pizza (Medium)", 1300},
        {"Club Sandwich", 500}
    };

    drinks_ = {
        {"Mineral Water", 80},
        {"Coke", 150},
        {"Pepsi", 150},
        {"Fresh Lime", 200},
        {"Orange Juice", 250},
        {"Tea", 120}
    };

    if (!dbOpen()) {
        cerr << "Failed to open DB.\n";
        return;
    }
    dbInitSchema();
    dbSeedDefaults();
    dbLoadAll();
}

HotelSystem::~HotelSystem() {
    dbClose();
}

bool HotelSystem::dbOpen() {
    if (sqlite3_open(dbPath_.c_str(), &db_) != SQLITE_OK) {
        cerr << "SQLite open error: " << sqlite3_errmsg(db_) << "\n";
        db_ = nullptr;
        return false;
    }
    dbExec("PRAGMA foreign_keys = ON;");
    return true;
}

void HotelSystem::dbClose() {
    if (db_) sqlite3_close(db_);
    db_ = nullptr;
}

bool HotelSystem::dbExec(const string& sql) {
    char* err = nullptr;
    int rc = sqlite3_exec(db_, sql.c_str(), nullptr, nullptr, &err);
    if (rc != SQLITE_OK) {
        cerr << "SQLite exec error: " << (err ? err : "unknown") << "\n";
        sqlite3_free(err);
        return false;
    }
    return true;
}

bool HotelSystem::dbInitSchema() {
    // users, rooms, customers, charges, servants, service history, bills
    const string schema = R"SQL(
    CREATE TABLE IF NOT EXISTS users(
        username TEXT PRIMARY KEY,
        password TEXT NOT NULL,
        role     INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS rooms(
        number INTEGER PRIMARY KEY,
        window INTEGER NOT NULL,
        ac     INTEGER NOT NULL,
        bed    INTEGER NOT NULL,
        price  INTEGER NOT NULL,
        occupied INTEGER NOT NULL,
        occupied_customer_id INTEGER
    );

    CREATE TABLE IF NOT EXISTS customers(
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        phone TEXT NOT NULL,
        room_no INTEGER,
        room_charge INTEGER NOT NULL,
        checked_in INTEGER NOT NULL,
        checkin_time INTEGER,
        checkout_time INTEGER
    );

    CREATE TABLE IF NOT EXISTS service_charges(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        category TEXT NOT NULL,
        description TEXT NOT NULL,
        amount INTEGER NOT NULL,
        at INTEGER NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );

    CREATE TABLE IF NOT EXISTS servants(
        id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        duty TEXT NOT NULL,
        salary INTEGER NOT NULL,
        paid INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS car_rentals(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        car_model TEXT NOT NULL,
        days INTEGER NOT NULL,
        amount INTEGER NOT NULL,
        at INTEGER NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );

    CREATE TABLE IF NOT EXISTS orders(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        item_name TEXT NOT NULL,
        unit_price INTEGER NOT NULL,
        qty INTEGER NOT NULL,
        at INTEGER NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );

    CREATE TABLE IF NOT EXISTS hospital(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        customer_id INTEGER NOT NULL,
        service TEXT NOT NULL,
        amount INTEGER NOT NULL,
        at INTEGER NOT NULL,
        FOREIGN KEY(customer_id) REFERENCES customers(id)
    );

    CREATE TABLE IF NOT EXISTS bills(
        bill_id INTEGER PRIMARY KEY,
        customer_id INTEGER NOT NULL,
        customer_name TEXT NOT NULL,
        room_no INTEGER NOT NULL,
        total INTEGER NOT NULL,
        at INTEGER NOT NULL
    );

    CREATE TABLE IF NOT EXISTS bill_items(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        bill_id INTEGER NOT NULL,
        label TEXT NOT NULL,
        amount INTEGER NOT NULL,
        FOREIGN KEY(bill_id) REFERENCES bills(bill_id)
    );
    )SQL";

    return dbExec(schema);
}

bool HotelSystem::dbSeedDefaults() {
    // Ensure admin exists
    // INSERT OR IGNORE keeps existing admin if already there.
    const string sql = "INSERT OR IGNORE INTO users(username,password,role) VALUES('admin','1234',2);";
    return dbExec(sql);
}

bool HotelSystem::dbLoadAll() {
    users_.clear();
    rooms_.clear();
    customers_.clear();
    servants_.clear();
    carRentals_.clear();
    orders_.clear();
    hospital_.clear();
    bills_.clear();
    while (!recentBillIds_.empty()) recentBillIds_.pop();

    // -------- Users --------
    {
        const char* q = "SELECT username,password,role FROM users;";
        sqlite3_stmt* st = nullptr;
        sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
        while (sqlite3_step(st) == SQLITE_ROW) {
            User u;
            u.username = (const char*)sqlite3_column_text(st, 0);
            u.password = (const char*)sqlite3_column_text(st, 1);
            u.role = (sqlite3_column_int(st, 2) == 1) ? Role::Receptionist : Role::Management;
            users_[u.username] = u;
        }
        sqlite3_finalize(st);
    }

    // -------- Rooms --------
    {
        const char* q = "SELECT number,window,ac,bed,price,occupied,occupied_customer_id FROM rooms;";
        sqlite3_stmt* st = nullptr;
        sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
        while (sqlite3_step(st) == SQLITE_ROW) {
            Room r;
            r.number = sqlite3_column_int(st, 0);
            r.window = sqlite3_column_int(st, 1) != 0;
            r.ac     = sqlite3_column_int(st, 2) != 0;
            r.bed    = (BedType)sqlite3_column_int(st, 3);
            r.pricePerNight = sqlite3_column_int(st, 4);
            r.occupied = sqlite3_column_int(st, 5) != 0;
            r.occupiedByCustomerId = sqlite3_column_type(st, 6) == SQLITE_NULL ? -1 : sqlite3_column_int(st, 6);
            rooms_[r.number] = r;
        }
        sqlite3_finalize(st);
    }

    // -------- Customers checked-in only --------
    {
        const char* q = "SELECT id,name,phone,room_no,room_charge FROM customers WHERE checked_in=1;";
        sqlite3_stmt* st = nullptr;
        sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
        while (sqlite3_step(st) == SQLITE_ROW) {
            Customer c;
            c.id = sqlite3_column_int(st, 0);
            c.name = (const char*)sqlite3_column_text(st, 1);
            c.phone = (const char*)sqlite3_column_text(st, 2);
            c.roomNo = sqlite3_column_type(st, 3) == SQLITE_NULL ? -1 : sqlite3_column_int(st, 3);
            c.roomCharge = sqlite3_column_int(st, 4);
            customers_[c.id] = c;
        }
        sqlite3_finalize(st);
    }

    // -------- Charges for checked-in customers --------
    {
        const char* q = "SELECT customer_id,category,description,amount FROM service_charges WHERE customer_id=? ORDER BY id;";
        sqlite3_stmt* st = nullptr;
        sqlite3_prepare_v2(db_, q, -1, &st, nullptr);

        for (auto &kv : customers_) {
            int cid = kv.first;
            Customer &c = kv.second;
            c.charges.clear();

            sqlite3_reset(st);
            sqlite3_clear_bindings(st);
            sqlite3_bind_int(st, 1, cid);

            while (sqlite3_step(st) == SQLITE_ROW) {
                ServiceCharge sc;
                sc.category = (const char*)sqlite3_column_text(st, 1);
                sc.description = (const char*)sqlite3_column_text(st, 2);
                sc.amount = sqlite3_column_int(st, 3);
                c.charges.push_back(sc);
            }
        }
        sqlite3_finalize(st);
    }

    // -------- Servants --------
    {
        const char* q = "SELECT id,name,duty,salary,paid FROM servants ORDER BY id;";
        sqlite3_stmt* st = nullptr;
        sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
        while (sqlite3_step(st) == SQLITE_ROW) {
            Servant s;
            s.id = sqlite3_column_int(st, 0);
            s.name = (const char*)sqlite3_column_text(st, 1);
            s.duty = (const char*)sqlite3_column_text(st, 2);
            s.monthlySalary = sqlite3_column_int(st, 3);
            s.paidThisMonth = sqlite3_column_int(st, 4) != 0;
            servants_.push_back(s);
            nextServantId_ = max(nextServantId_, s.id + 1);
        }
        sqlite3_finalize(st);
    }

    // -------- Car rentals, orders, hospital (history) --------
    {
        sqlite3_stmt* st = nullptr;

        sqlite3_prepare_v2(db_, "SELECT customer_id,car_model,days,amount,at FROM car_rentals;", -1, &st, nullptr);
        while (sqlite3_step(st) == SQLITE_ROW) {
            CarRental r;
            r.customerId = sqlite3_column_int(st, 0);
            r.carModel   = (const char*)sqlite3_column_text(st, 1);
            r.days       = sqlite3_column_int(st, 2);
            r.amount     = sqlite3_column_int(st, 3);
            r.at         = (time_t)sqlite3_column_int64(st, 4);
            carRentals_.push_back(r);
        }
        sqlite3_finalize(st);

        sqlite3_prepare_v2(db_, "SELECT customer_id,item_name,unit_price,qty,at FROM orders;", -1, &st, nullptr);
        while (sqlite3_step(st) == SQLITE_ROW) {
            OrderItem o;
            o.customerId = sqlite3_column_int(st, 0);
            o.itemName   = (const char*)sqlite3_column_text(st, 1);
            o.unitPrice  = sqlite3_column_int(st, 2);
            o.qty        = sqlite3_column_int(st, 3);
            o.at         = (time_t)sqlite3_column_int64(st, 4);
            orders_.push_back(o);
        }
        sqlite3_finalize(st);

        sqlite3_prepare_v2(db_, "SELECT customer_id,service,amount,at FROM hospital;", -1, &st, nullptr);
        while (sqlite3_step(st) == SQLITE_ROW) {
            HospitalRecord h;
            h.customerId = sqlite3_column_int(st, 0);
            h.service    = (const char*)sqlite3_column_text(st, 1);
            h.amount     = sqlite3_column_int(st, 2);
            h.at         = (time_t)sqlite3_column_int64(st, 3);
            hospital_.push_back(h);
        }
        sqlite3_finalize(st);
    }

    // -------- Bills + bill items --------
    {
        const char* qb = "SELECT bill_id,customer_id,customer_name,room_no,total,at FROM bills ORDER BY bill_id;";
        sqlite3_stmt* stB = nullptr;
        sqlite3_prepare_v2(db_, qb, -1, &stB, nullptr);

        // prepare items stmt once
        sqlite3_stmt* stI = nullptr;
        sqlite3_prepare_v2(db_, "SELECT label,amount FROM bill_items WHERE bill_id=? ORDER BY id;", -1, &stI, nullptr);

        while (sqlite3_step(stB) == SQLITE_ROW) {
            Bill b;
            b.billId = sqlite3_column_int(stB, 0);
            b.customerId = sqlite3_column_int(stB, 1);
            b.customerName = (const char*)sqlite3_column_text(stB, 2);
            b.roomNo = sqlite3_column_int(stB, 3);
            b.total = sqlite3_column_int(stB, 4);
            b.at = (time_t)sqlite3_column_int64(stB, 5);

            // load items
            b.items.clear();
            sqlite3_reset(stI);
            sqlite3_clear_bindings(stI);
            sqlite3_bind_int(stI, 1, b.billId);
            while (sqlite3_step(stI) == SQLITE_ROW) {
                BillItem bi;
                bi.label = (const char*)sqlite3_column_text(stI, 0);
                bi.amount = sqlite3_column_int(stI, 1);
                b.items.push_back(bi);
            }

            bills_.push_back(b);
            recentBillIds_.push(b.billId);
            nextBillId_ = max(nextBillId_, b.billId + 1);
        }

        sqlite3_finalize(stI);
        sqlite3_finalize(stB);
    }

    return true;
}

// ---------- Write-through helpers ----------
bool HotelSystem::dbUpsertUser(const User& u) {
    const char* q = "INSERT INTO users(username,password,role) VALUES(?,?,?) "
                    "ON CONFLICT(username) DO UPDATE SET password=excluded.password, role=excluded.role;";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_text(st, 1, u.username.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(st, 2, u.password.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(st, 3, (u.role == Role::Receptionist) ? 1 : 2);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbInsertRoom(const Room& r) {
    const char* q = "INSERT INTO rooms(number,window,ac,bed,price,occupied,occupied_customer_id) VALUES(?,?,?,?,?,?,?);";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, r.number);
    sqlite3_bind_int(st, 2, r.window ? 1 : 0);
    sqlite3_bind_int(st, 3, r.ac ? 1 : 0);
    sqlite3_bind_int(st, 4, (int)r.bed);
    sqlite3_bind_int(st, 5, r.pricePerNight);
    sqlite3_bind_int(st, 6, r.occupied ? 1 : 0);
    if (r.occupiedByCustomerId < 0) sqlite3_bind_null(st, 7);
    else sqlite3_bind_int(st, 7, r.occupiedByCustomerId);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbUpdateRoom(const Room& r) {
    const char* q = "UPDATE rooms SET window=?,ac=?,bed=?,price=?,occupied=?,occupied_customer_id=? WHERE number=?;";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, r.window ? 1 : 0);
    sqlite3_bind_int(st, 2, r.ac ? 1 : 0);
    sqlite3_bind_int(st, 3, (int)r.bed);
    sqlite3_bind_int(st, 4, r.pricePerNight);
    sqlite3_bind_int(st, 5, r.occupied ? 1 : 0);
    if (r.occupiedByCustomerId < 0) sqlite3_bind_null(st, 6);
    else sqlite3_bind_int(st, 6, r.occupiedByCustomerId);
    sqlite3_bind_int(st, 7, r.number);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbInsertCustomerCheckedIn(const Customer& c) {
    const char* q = "INSERT INTO customers(id,name,phone,room_no,room_charge,checked_in,checkin_time,checkout_time) "
                    "VALUES(?,?,?,?,?,1,?,NULL);";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, c.id);
    sqlite3_bind_text(st, 2, c.name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(st, 3, c.phone.c_str(), -1, SQLITE_TRANSIENT);
    if (c.roomNo < 0) sqlite3_bind_null(st, 4);
    else sqlite3_bind_int(st, 4, c.roomNo);
    sqlite3_bind_int(st, 5, c.roomCharge);
    sqlite3_bind_int64(st, 6, (sqlite3_int64)time(nullptr));
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbSetCustomerCheckout(int customerId) {
    const char* q = "UPDATE customers SET checked_in=0, checkout_time=? WHERE id=?;";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int64(st, 1, (sqlite3_int64)time(nullptr));
    sqlite3_bind_int(st, 2, customerId);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbInsertCharge(int customerId, const ServiceCharge& sc) {
    const char* q = "INSERT INTO service_charges(customer_id,category,description,amount,at) VALUES(?,?,?,?,?);";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, customerId);
    sqlite3_bind_text(st, 2, sc.category.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(st, 3, sc.description.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(st, 4, sc.amount);
    sqlite3_bind_int64(st, 5, (sqlite3_int64)time(nullptr));
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbInsertServant(const Servant& s) {
    const char* q = "INSERT INTO servants(id,name,duty,salary,paid) VALUES(?,?,?,?,?);";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, s.id);
    sqlite3_bind_text(st, 2, s.name.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_text(st, 3, s.duty.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(st, 4, s.monthlySalary);
    sqlite3_bind_int(st, 5, s.paidThisMonth ? 1 : 0);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbUpdateServantPaid(int servantId, bool paid) {
    const char* q = "UPDATE servants SET paid=? WHERE id=?;";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, paid ? 1 : 0);
    sqlite3_bind_int(st, 2, servantId);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbInsertCarRental(const CarRental& r) {
    const char* q = "INSERT INTO car_rentals(customer_id,car_model,days,amount,at) VALUES(?,?,?,?,?);";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, r.customerId);
    sqlite3_bind_text(st, 2, r.carModel.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(st, 3, r.days);
    sqlite3_bind_int(st, 4, r.amount);
    sqlite3_bind_int64(st, 5, (sqlite3_int64)r.at);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbInsertOrder(const OrderItem& o) {
    const char* q = "INSERT INTO orders(customer_id,item_name,unit_price,qty,at) VALUES(?,?,?,?,?);";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, o.customerId);
    sqlite3_bind_text(st, 2, o.itemName.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(st, 3, o.unitPrice);
    sqlite3_bind_int(st, 4, o.qty);
    sqlite3_bind_int64(st, 5, (sqlite3_int64)o.at);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbInsertHospital(const HospitalRecord& h) {
    const char* q = "INSERT INTO hospital(customer_id,service,amount,at) VALUES(?,?,?,?);";
    sqlite3_stmt* st = nullptr;
    sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
    sqlite3_bind_int(st, 1, h.customerId);
    sqlite3_bind_text(st, 2, h.service.c_str(), -1, SQLITE_TRANSIENT);
    sqlite3_bind_int(st, 3, h.amount);
    sqlite3_bind_int64(st, 4, (sqlite3_int64)h.at);
    bool ok = stepDone(db_, st);
    sqlite3_finalize(st);
    return ok;
}

bool HotelSystem::dbInsertBill(const Bill& b) {
    // transaction for bill + items
    dbExec("BEGIN;");

    {
        const char* q = "INSERT INTO bills(bill_id,customer_id,customer_name,room_no,total,at) VALUES(?,?,?,?,?,?);";
        sqlite3_stmt* st = nullptr;
        sqlite3_prepare_v2(db_, q, -1, &st, nullptr);
        sqlite3_bind_int(st, 1, b.billId);
        sqlite3_bind_int(st, 2, b.customerId);
        sqlite3_bind_text(st, 3, b.customerName.c_str(), -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(st, 4, b.roomNo);
        sqlite3_bind_int(st, 5, b.total);
        sqlite3_bind_int64(st, 6, (sqlite3_int64)b.at);
        if (!stepDone(db_, st)) { sqlite3_finalize(st); dbExec("ROLLBACK;"); return false; }
        sqlite3_finalize(st);
    }

    {
        const char* qi = "INSERT INTO bill_items(bill_id,label,amount) VALUES(?,?,?);";
        sqlite3_stmt* st = nullptr;
        sqlite3_prepare_v2(db_, qi, -1, &st, nullptr);

        for (const auto& it : b.items) {
            sqlite3_reset(st);
            sqlite3_clear_bindings(st);
            sqlite3_bind_int(st, 1, b.billId);
            sqlite3_bind_text(st, 2, it.label.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_int(st, 3, it.amount);
            if (!stepDone(db_, st)) { sqlite3_finalize(st); dbExec("ROLLBACK;"); return false; }
        }
        sqlite3_finalize(st);
    }

    dbExec("COMMIT;");
    return true;
}

// ---------------- Management (same UI, now saves in DB) ----------------
void HotelSystem::managementMenu() {
    while (true) {
        cout << "\n--- Management Menu ---\n";
        cout << "1. Add Room\n";
        cout << "2. Hire Servant\n";
        cout << "3. Pay Servant\n";
        cout << "4. View Servants\n";
        cout << "0. Back\n";
        int ch = util::getInt("Choose: ", 0, 4);
        if (ch == 0) break;
        if (ch == 1) addRoom();
        if (ch == 2) hireServant();
        if (ch == 3) payServant();
        if (ch == 4) viewServants();
    }
}

void HotelSystem::addRoom() {
    cout << "\n--- Add Room ---\n";
    int roomNo = util::getInt("Room Number (1..9999): ", 1, 9999);
    if (rooms_.count(roomNo)) { cout << "Room already exists.\n"; return; }

    int win = util::getInt("Window? (1=Yes, 0=No): ", 0, 1);
    int ac  = util::getInt("AC? (1=Yes, 0=No): ", 0, 1);
    cout << "Bed Type:\n1. Single\n2. Twin\n3. Double\n";
    int bt  = util::getInt("Choose: ", 1, 3);

    Room r;
    r.number = roomNo;
    r.window = (win == 1);
    r.ac = (ac == 1);
    r.bed = (bt == 1 ? BedType::Single : bt == 2 ? BedType::Twin : BedType::Double);

    int price = 2000;
    if (r.ac) price += 1000;
    if (r.window) price += 300;
    if (r.bed == BedType::Twin) price += 500;
    if (r.bed == BedType::Double) price += 900;
    r.pricePerNight = price;

    r.occupied = false;
    r.occupiedByCustomerId = -1;

    if (!dbInsertRoom(r)) { cout << "DB error: room not saved.\n"; return; }
    rooms_[roomNo] = r;

    cout << "Room added (Price/Night: Rs " << price << ").\n";
}

void HotelSystem::hireServant() {
    cout << "\n--- Hire Servant ---\n";
    Servant s;
    s.id = nextServantId_++;
    s.name = util::getLine("Name: ");
    s.duty = util::getLine("Duty (Housekeeping/Driver/Chef/etc): ");
    s.monthlySalary = util::getInt("Monthly Salary (1000..1000000): ", 1000, 1000000);
    s.paidThisMonth = false;

    if (!dbInsertServant(s)) { cout << "DB error: servant not saved.\n"; return; }
    servants_.push_back(s);

    cout << "Servant hired. ID: " << s.id << "\n";
}

void HotelSystem::payServant() {
    cout << "\n--- Pay Servant ---\n";
    if (servants_.empty()) { cout << "No servants.\n"; return; }

    int sid = util::getInt("Enter Servant ID: ", 1, 1000000);
    for (auto &s : servants_) {
        if (s.id == sid) {
            if (s.paidThisMonth) {
                cout << "Already paid this month.\n";
            } else {
                s.paidThisMonth = true;
                dbUpdateServantPaid(s.id, true);
                cout << "Paid Rs " << s.monthlySalary << " to " << s.name << ".\n";
            }
            return;
        }
    }
    cout << "Servant not found.\n";
}

void HotelSystem::viewServants() {
    cout << "\n--- Servants ---\n";
    if (servants_.empty()) { cout << "No servants.\n"; return; }

    for (const auto &s : servants_) {
        cout << "ID: " << s.id
             << " | Name: " << s.name
             << " | Duty: " << s.duty
             << " | Salary: Rs " << s.monthlySalary
             << " | " << (s.paidThisMonth ? "Paid" : "Unpaid") << "\n";
    }
}
