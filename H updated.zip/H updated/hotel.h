#ifndef HOTEL_H
#define HOTEL_H

#include <iostream>
#include <string>
#include <vector>
#include <unordered_map>
#include <map>
#include <stack>
#include <optional>
#include <ctime>
#include <algorithm>
#include <limits>
#include <sqlite3.h>
using namespace std;

// ---------- Helpers ----------
namespace util {
    inline void clearBadInput() {
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    inline int getInt(const string& prompt, int minV, int maxV) {
        while (true) {
            cout << prompt;
            long long x;
            if (cin >> x && x >= minV && x <= maxV) {
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                return (int)x;
            }
            cout << "Invalid input. Please enter a number between " << minV << " and " << maxV << ".\n";
            clearBadInput();
        }
    }

    inline string getLine(const string& prompt) {
        cout << prompt;
        string s;
        getline(cin, s);
        while (!s.empty() && (s.back()=='\r' || s.back()=='\n')) s.pop_back();
        return s;
    }
}

// ---------- Types ----------
enum class Role { Receptionist = 1, Management = 2 };
inline string roleToString(Role r) {
    return (r == Role::Receptionist) ? "Receptionist" : "Management";
}

enum class BedType { Single = 1, Twin = 2, Double = 3 };
inline string bedToString(BedType b) {
    switch (b) {
        case BedType::Single: return "Single";
        case BedType::Twin:   return "Twin";
        case BedType::Double: return "Double";
    }
    return "Unknown";
}

struct User {
    string username;
    string password;
    Role role;
};

struct Room {
    int number{};
    bool window{};
    bool ac{};
    BedType bed{BedType::Single};
    int pricePerNight{};
    bool occupied{};
    int occupiedByCustomerId{-1};
};

struct ServiceCharge {
    string category;
    string description;
    int amount{};
};

struct Customer {
    int id{};
    string name;
    string phone;
    int roomNo{-1};
    int roomCharge{};
    vector<ServiceCharge> charges; // loaded from DB service_charges table
};

struct Servant {
    int id{};
    string name;
    string duty;
    int monthlySalary{};
    bool paidThisMonth{false};
};

struct CarType { string model; int rentPerDay{}; };

struct CarRental {
    int customerId{};
    string carModel;
    int days{};
    int amount{};
    time_t at{};
};

struct MenuItem { string name; int price{}; };

struct OrderItem {
    int customerId{};
    string itemName;
    int unitPrice{};
    int qty{};
    time_t at{};
};

struct HospitalRecord {
    int customerId{};
    string service;
    int amount{};
    time_t at{};
};

struct BillItem { string label; int amount{}; };

struct Bill {
    int billId{};
    int customerId{};
    string customerName;
    int roomNo{};
    vector<BillItem> items;
    int total{};
    time_t at{};
};

// ---------- System ----------
class HotelSystem {
public:
    HotelSystem();
    ~HotelSystem();

    void run(); // login.cpp

private:
    // SQLite
    sqlite3* db_ = nullptr;
    string dbPath_ = "hotel.db";

    bool dbOpen();
    void dbClose();
    bool dbExec(const string& sql);
    bool dbInitSchema();
    bool dbSeedDefaults();
    bool dbLoadAll();

    // Write-through helpers
    bool dbUpsertUser(const User& u);
    bool dbInsertRoom(const Room& r);
    bool dbUpdateRoom(const Room& r);

    bool dbInsertCustomerCheckedIn(const Customer& c);
    bool dbSetCustomerCheckout(int customerId);
    bool dbInsertCharge(int customerId, const ServiceCharge& sc);

    bool dbInsertServant(const Servant& s);
    bool dbUpdateServantPaid(int servantId, bool paid);

    bool dbInsertCarRental(const CarRental& r);
    bool dbInsertOrder(const OrderItem& o);
    bool dbInsertHospital(const HospitalRecord& h);

    bool dbInsertBill(const Bill& b);

    // In-memory cache (loaded from DB on startup)
    unordered_map<string, User> users_;
    unordered_map<int, Room> rooms_;
    unordered_map<int, Customer> customers_; // ONLY checked-in customers
    vector<Servant> servants_;

    vector<CarType> carTypes_;
    vector<MenuItem> dishes_;
    vector<MenuItem> drinks_;

    vector<CarRental> carRentals_;
    vector<OrderItem> orders_;
    vector<HospitalRecord> hospital_;

    vector<Bill> bills_;
    stack<int> recentBillIds_;

    int nextServantId_ = 1;
    int nextBillId_ = 1001;

    // auth + main menu
    void signUp();
    optional<User> login();
    void sessionMenu(const User& user);

    // receptionist
    void receptionistMenu();
    void bookRoom();
    void viewRooms();
    void viewCustomers();

    // management
    void managementMenu();
    void addRoom();
    void hireServant();
    void payServant();
    void viewServants();

    // services
    void otherServicesMenu();
    optional<Customer*> getActiveCustomerById();

    void carServiceMenu();
    void rentCar();
    void viewRentedCars();

    void restaurantMenu();
    void showMenuCard();
    void placeOrder();
    void viewCustomerOrders();

    void hospitalMenu();
    void addHospitalService();
    void viewHospitalServices();

    // billing
    void checkoutMenu();
    void checkoutCustomer();
    void printBill(const Bill& b);
    void viewBills();
    void viewMostRecentBill();
};

#endif
