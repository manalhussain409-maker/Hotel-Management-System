#include "hotel.h"

void HotelSystem::checkoutMenu() {
    while (true) {
        cout << "\n--- Checkout ---\n";
        cout << "1. Generate Bill (Checkout Customer)\n";
        cout << "2. View Bills\n";
        cout << "3. View Most Recent Bill\n";
        cout << "0. Back\n";

        int ch = util::getInt("Choose: ", 0, 3);
        if (ch == 0) break;

        if (ch == 1) checkoutCustomer();
        if (ch == 2) viewBills();
        if (ch == 3) viewMostRecentBill();
    }
}

void HotelSystem::checkoutCustomer() {
    cout << "\n--- Checkout Customer ---\n";
    int cid = util::getInt("Customer ID: ", 1, 999999);

    auto it = customers_.find(cid);
    if (it == customers_.end()) {
        cout << "Customer not found.\n";
        return;
    }
    Customer &c = it->second;

    Bill b;
    b.billId = nextBillId_++;
    b.customerId = c.id;
    b.customerName = c.name;
    b.roomNo = c.roomNo;
    b.at = time(nullptr);

    b.items.push_back(BillItem{"Room Charge (per night basis)", c.roomCharge});
    int total = c.roomCharge;

    for (const auto &sc : c.charges) {
        b.items.push_back(BillItem{sc.category + ": " + sc.description, sc.amount});
        total += sc.amount;
    }
    b.total = total;

    // Save bill to DB (bill + items)
    if (!dbInsertBill(b)) {
        cout << "DB error: bill not saved.\n";
        return;
    }

    // Update customer checkout in DB
    dbSetCustomerCheckout(cid);

    // free room in DB
    auto rit = rooms_.find(c.roomNo);
    if (rit != rooms_.end()) {
        rit->second.occupied = false;
        rit->second.occupiedByCustomerId = -1;
        dbUpdateRoom(rit->second);
    }

    // cache updates
    bills_.push_back(b);
    recentBillIds_.push(b.billId);
    customers_.erase(it);

    printBill(b);
    cout << "Checkout complete. Customer removed from active list.\n";
}

void HotelSystem::printBill(const Bill& b) {
    cout << "\n=========== BILL ===========\n";
    cout << "Bill ID: " << b.billId << "\n";
    cout << "Customer: " << b.customerName << " (ID " << b.customerId << ")\n";
    cout << "Room No: " << b.roomNo << "\n";
    cout << "----------------------------\n";
    for (const auto &it : b.items) {
        cout << it.label << " : Rs " << it.amount << "\n";
    }
    cout << "----------------------------\n";
    cout << "TOTAL: Rs " << b.total << "\n";
    cout << "============================\n";
}

void HotelSystem::viewBills() {
    cout << "\n--- Bills ---\n";
    if (bills_.empty()) { cout << "No bills generated yet.\n"; return; }

    cout << "1. List all bills\n";
    cout << "2. View by Bill ID\n";
    int ch = util::getInt("Choose: ", 1, 2);

    if (ch == 1) {
        for (const auto &b : bills_) {
            cout << "BillID " << b.billId
                 << " | CustomerID " << b.customerId
                 << " | Room " << b.roomNo
                 << " | Total Rs " << b.total << "\n";
        }
    } else {
        int bid = util::getInt("Bill ID: ", 1001, 9999999);
        for (const auto &b : bills_) {
            if (b.billId == bid) { printBill(b); return; }
        }
        cout << "Bill not found.\n";
    }
}

void HotelSystem::viewMostRecentBill() {
    cout << "\n--- Most Recent Bill ---\n";
    if (recentBillIds_.empty()) {
        cout << "No bills yet.\n";
        return;
    }

    int bid = recentBillIds_.top();
    for (const auto &b : bills_) {
        if (b.billId == bid) { printBill(b); return; }
    }
    cout << "Recent bill not found.\n";
}
