1) Create accounts (Sign up) / Log in
Option A: Use default Management account

Username: admin

Password: 1234

Option B: Create your own users

Start program

Choose 2) Sign up

Enter username + password

Select role:

1 = Receptionist

2 = Management

Then go back and Log in with that user

2) Management flow (must be done first)

✅ You cannot book customers until rooms exist

Log in as Management (admin or any Management user)

From Main Menu choose 2) Management

Do these in order:

A) Add Rooms

Choose 1) Add Room

Add rooms like: 101, 102, 103…

For each room choose:

window (yes/no)

AC (yes/no)

bed type (single/twin/double)

✅ Now Receptionist can book rooms.

B) Hire Servants (optional)

Choose 2) Hire Servant

Enter name, duty, salary

C) Pay Servants (optional)

Choose 3) Pay Servant

Enter servant ID

D) View Servants (optional)

Choose 4) View Servants

3) Receptionist flow (Check-in customers)

Log in as Receptionist (or admin can also do it)

From Main Menu choose 1) Receptionalist

A) Add Customer / Book Room (Check-in)

Choose 1) Add Customer / Book Room

Enter:

Customer ID (unique number)

Customer name

Phone

Select an available room number (e.g., 101)

Choose room services:

Window / Non-window

AC / Non-AC

Bed type

Booking saves to DB and room becomes Occupied

B) View Rooms

Choose 2) View Rooms

You’ll see which are Available/Occupied

C) View Customers

Choose 3) View Customers

Shows only currently checked-in customers

4) Other Services flow (ONLY for checked-in customers)

✅ These require a valid checked-in Customer ID

From Main Menu choose 3) Other Services

A) Car Service

Choose 1) Car Service

Choose:

1) Rent a Car

Enter Customer ID

Select car model

Enter number of days

Charge gets saved + added to customer

2) View Rent Cars (history list)

B) Restaurant Service

Choose 2) Restaurant Service

Options:

1) Show Menu Card (10 dishes + 6 drinks)

2) Place Order

Enter Customer ID

Pick dish/drink

Enter quantity

Repeat until done

Charges saved + added to customer

3) View Customer Orders

Enter Customer ID to view order history

C) Hospital Service

Choose 3) Hospital Service

Options:

1) Add Emergency / Medical Service

Enter Customer ID

Write service description

Enter charge amount

Saves record + adds charge

2) View Hospital Services Used

Enter Customer ID to view history

5) Checkout flow (Bill generation + room becomes free)

✅ Checkout should be done at the end for a customer.

From Main Menu choose 4) Checkout

Choose 1) Generate Bill (Checkout Customer)

Enter Customer ID

System will:

Generate bill (room + all service charges)

Save bill in DB

Mark customer as checked-out

Free the room (Occupied → Available)

Remove customer from “Active Customers”

View bills

2) View Bills → list or view by bill ID

3) View Most Recent Bill

Quick correct usage example (real workflow)

Login as admin

Management → Add Room 101, 102

Logout

Login as Receptionist

Receptionist → Book customer (ID 1) in room 101

Other Services → Restaurant → Order items for customer ID 1

Other Services → Car → Rent car for customer ID 1

Checkout → Generate bill for customer ID 1