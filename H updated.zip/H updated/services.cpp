#include "hotel.h"

optional<Customer*> HotelSystem::getActiveCustomerById() {
    int cid = util::getInt("Customer ID: ", 1, 999999);
    auto it = customers_.find(cid);
    if (it == customers_.end()) {
        cout << "Customer not found (must be checked-in).\n";
        return nullopt;
    }
    return &it->second;
}

void HotelSystem::otherServicesMenu() {
    while (true) {
        cout << "\n--- Other Services ---\n";
        cout << "1. Car Service\n";
        cout << "2. Restaurant Service\n";
        cout << "3. Hospital Service\n";
        cout << "0. Back\n";

        int ch = util::getInt("Choose: ", 0, 3);
        if (ch == 0) break;

        if (ch == 1) carServiceMenu();
        if (ch == 2) restaurantMenu();
        if (ch == 3) hospitalMenu();
    }
}

// ---------------- Car Service ----------------
void HotelSystem::carServiceMenu() {
    while (true) {
        cout << "\n--- Car Service ---\n";
        cout << "1. Rent a Car\n";
        cout << "2. View Rent Cars\n";
        cout << "0. Back\n";

        int ch = util::getInt("Choose: ", 0, 2);
        if (ch == 0) break;

        if (ch == 1) rentCar();
        if (ch == 2) viewRentedCars();
    }
}

void HotelSystem::rentCar() {
    cout << "\n--- Rent a Car ---\n";
    auto custOpt = getActiveCustomerById();
    if (!custOpt) return;
    Customer* c = *custOpt;

    cout << "Available cars:\n";
    for (size_t i = 0; i < carTypes_.size(); i++) {
        cout << i+1 << ". " << carTypes_[i].model
             << " - Rs " << carTypes_[i].rentPerDay << " per day\n";
    }

    int idx = util::getInt("Select car (1.." + to_string((int)carTypes_.size()) + "): ", 1, (int)carTypes_.size()) - 1;
    int days = util::getInt("Days (1..60): ", 1, 60);

    const CarType& car = carTypes_[idx];
    int amount = car.rentPerDay * days;

    CarRental r{c->id, car.model, days, amount, time(nullptr)};
    ServiceCharge sc{"Car", car.model + " (" + to_string(days) + " day(s))", amount};

    // DB write
    dbInsertCarRental(r);
    dbInsertCharge(c->id, sc);

    // cache
    carRentals_.push_back(r);
    c->charges.push_back(sc);

    cout << "Car rented. Charge added: Rs " << amount << "\n";
}

void HotelSystem::viewRentedCars() {
    cout << "\n--- View Rent Cars ---\n";
    if (carRentals_.empty()) { cout << "No rentals.\n"; return; }

    for (const auto &r : carRentals_) {
        cout << "CustomerID " << r.customerId
             << " | " << r.carModel
             << " | Days: " << r.days
             << " | Amount: Rs " << r.amount << "\n";
    }
}

// ---------------- Restaurant ----------------
void HotelSystem::restaurantMenu() {
    while (true) {
        cout << "\n--- Restaurant Service ---\n";
        cout << "1. Show Menu Card (10 dishes + 6 drinks)\n";
        cout << "2. Place Order\n";
        cout << "3. View Customer Orders\n";
        cout << "0. Back\n";

        int ch = util::getInt("Choose: ", 0, 3);
        if (ch == 0) break;

        if (ch == 1) showMenuCard();
        if (ch == 2) placeOrder();
        if (ch == 3) viewCustomerOrders();
    }
}

void HotelSystem::showMenuCard() {
    cout << "\n=== MENU CARD ===\n";
    cout << "\n--- 10 Dishes ---\n";
    for (size_t i = 0; i < dishes_.size(); i++) {
        cout << i+1 << ". " << dishes_[i].name << " - Rs " << dishes_[i].price << "\n";
    }

    cout << "\n--- 6 Drinks ---\n";
    for (size_t i = 0; i < drinks_.size(); i++) {
        cout << i+1 << ". " << drinks_[i].name << " - Rs " << drinks_[i].price << "\n";
    }
}

void HotelSystem::placeOrder() {
    cout << "\n--- Place Order ---\n";
    auto custOpt = getActiveCustomerById();
    if (!custOpt) return;
    Customer* c = *custOpt;

    showMenuCard();

    while (true) {
        cout << "\nOrder Type:\n1. Dish\n2. Drink\n0. Done\n";
        int type = util::getInt("Choose: ", 0, 2);
        if (type == 0) break;

        if (type == 1) {
            int idx = util::getInt("Dish no (1..10): ", 1, (int)dishes_.size()) - 1;
            int qty = util::getInt("Quantity (1..50): ", 1, 50);

            const auto& item = dishes_[idx];
            int amount = item.price * qty;

            OrderItem o{c->id, item.name, item.price, qty, time(nullptr)};
            ServiceCharge sc{"Restaurant", item.name + " x" + to_string(qty), amount};

            dbInsertOrder(o);
            dbInsertCharge(c->id, sc);

            orders_.push_back(o);
            c->charges.push_back(sc);

            cout << "Added: " << item.name << " x" << qty << " (Rs " << amount << ")\n";
        } else {
            int idx = util::getInt("Drink no (1..6): ", 1, (int)drinks_.size()) - 1;
            int qty = util::getInt("Quantity (1..50): ", 1, 50);

            const auto& item = drinks_[idx];
            int amount = item.price * qty;

            OrderItem o{c->id, item.name, item.price, qty, time(nullptr)};
            ServiceCharge sc{"Restaurant", item.name + " x" + to_string(qty), amount};

            dbInsertOrder(o);
            dbInsertCharge(c->id, sc);

            orders_.push_back(o);
            c->charges.push_back(sc);

            cout << "Added: " << item.name << " x" << qty << " (Rs " << amount << ")\n";
        }
    }

    cout << "Order complete.\n";
}

void HotelSystem::viewCustomerOrders() {
    cout << "\n--- View Customer Orders ---\n";
    int cid = util::getInt("Customer ID: ", 1, 999999);

    bool any = false;
    for (const auto& o : orders_) {
        if (o.customerId == cid) {
            any = true;
            cout << o.itemName
                 << " | Qty: " << o.qty
                 << " | Unit: Rs " << o.unitPrice
                 << " | Amount: Rs " << (o.unitPrice * o.qty) << "\n";
        }
    }
    if (!any) cout << "No orders found for this customer.\n";
}

// ---------------- Hospital ----------------
void HotelSystem::hospitalMenu() {
    while (true) {
        cout << "\n--- Hospital Service ---\n";
        cout << "1. Add Emergency / Medical Service\n";
        cout << "2. View Hospital Services Used\n";
        cout << "0. Back\n";

        int ch = util::getInt("Choose: ", 0, 2);
        if (ch == 0) break;

        if (ch == 1) addHospitalService();
        if (ch == 2) viewHospitalServices();
    }
}

void HotelSystem::addHospitalService() {
    cout << "\n--- Add Hospital Service ---\n";
    auto custOpt = getActiveCustomerById();
    if (!custOpt) return;
    Customer* c = *custOpt;

    string service = util::getLine("Service/Issue (First Aid/Ambulance/Doctor Visit): ");
    int amount = util::getInt("Charge (0..500000): ", 0, 500000);

    HospitalRecord h{c->id, service, amount, time(nullptr)};
    ServiceCharge sc{"Hospital", service, amount};

    dbInsertHospital(h);
    dbInsertCharge(c->id, sc);

    hospital_.push_back(h);
    c->charges.push_back(sc);

    cout << "Hospital service recorded. Charge added: Rs " << amount << "\n";
}

void HotelSystem::viewHospitalServices() {
    cout << "\n--- View Hospital Services Used ---\n";
    int cid = util::getInt("Customer ID: ", 1, 999999);

    bool any = false;
    for (const auto &h : hospital_) {
        if (h.customerId == cid) {
            any = true;
            cout << h.service << " | Amount: Rs " << h.amount << "\n";
        }
    }
    if (!any) cout << "No hospital services found for this customer.\n";
}
