#include "hotel.h"

void HotelSystem::run() {
    while (true) {
        cout << "\n===== ROYAL GARDEN HOTEL =====\n";
        cout << "1. Log in\n";
        cout << "2. Sign up\n";
        cout << "0. Exit\n";

        int ch = util::getInt("Choose: ", 0, 2);
        if (ch == 0) break;

        if (ch == 2) signUp();
        if (ch == 1) {
            auto userOpt = login();
            if (userOpt.has_value()) sessionMenu(*userOpt);
        }
    }
    cout << "Goodbye.\n";
}

void HotelSystem::signUp() {
    cout << "\n--- Sign up ---\n";
    string username = util::getLine("Username: ");
    if (username.empty()) { cout << "Username cannot be empty.\n"; return; }
    if (users_.count(username)) { cout << "Username already exists.\n"; return; }

    string password = util::getLine("Password: ");
    if (password.size() < 3) { cout << "Password must be at least 3 characters.\n"; return; }

    cout << "Role:\n1. Receptionist\n2. Management\n";
    int r = util::getInt("Choose role: ", 1, 2);
    Role role = (r == 1) ? Role::Receptionist : Role::Management;

    User u{username, password, role};

    if (!dbUpsertUser(u)) { cout << "DB error: user not saved.\n"; return; }
    users_[username] = u;

    cout << "Account created! Now log in.\n";
}

optional<User> HotelSystem::login() {
    cout << "\n--- Log in ---\n";
    string username = util::getLine("Username: ");
    string password = util::getLine("Password: ");

    auto it = users_.find(username);
    if (it == users_.end() || it->second.password != password) {
        cout << "Invalid username or password.\n";
        return nullopt;
    }

    cout << "Login successful. Role: " << roleToString(it->second.role) << "\n";
    return it->second;
}

void HotelSystem::sessionMenu(const User& user) {
    while (true) {
        cout << "\n===== MAIN MENU (" << user.username << " / " << roleToString(user.role) << ") =====\n";
        cout << "1. Receptionalist\n";
        cout << "2. Management\n";
        cout << "3. Other Services\n";
        cout << "4. Checkout\n";
        cout << "0. Log out\n";

        int ch = util::getInt("Choose: ", 0, 4);
        if (ch == 0) break;

        if (ch == 1) {
            receptionistMenu();
        } else if (ch == 2) {
            if (user.role != Role::Management) {
                cout << "Access denied. Management only.\n";
            } else {
                managementMenu();
            }
        } else if (ch == 3) {
            otherServicesMenu();
        } else if (ch == 4) {
            checkoutMenu();
        }
    }
}
