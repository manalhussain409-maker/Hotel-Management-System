#include "hotel.h"

void HotelSystem::receptionistMenu() {
    while (true) {
        cout << "\n--- Receptionist Menu ---\n";
        cout << "1. Add Customer / Book Room\n";
        cout << "2. View Rooms\n";
        cout << "3. View Customers\n";
        cout << "0. Back\n";

        int ch = util::getInt("Choose: ", 0, 3);
        if (ch == 0) break;

        if (ch == 1) bookRoom();
        if (ch == 2) viewRooms();
        if (ch == 3) viewCustomers();
    }
}

void HotelSystem::bookRoom() {
    if (rooms_.empty()) {
        cout << "No rooms found. Ask Management to add rooms first.\n";
        return;
    }

    cout << "\n--- Book Room ---\n";
    int cid = util::getInt("Customer ID (1..999999): ", 1, 999999);
    if (customers_.count(cid)) {
        cout << "Customer already checked-in with this ID.\n";
        return;
    }

    string name  = util::getLine("Customer Name: ");
    string phone = util::getLine("Phone: ");

    vector<int> available;
    for (auto &kv : rooms_) if (!kv.second.occupied) available.push_back(kv.first);
    sort(available.begin(), available.end());

    if (available.empty()) {
        cout << "No available rooms right now.\n";
        return;
    }

    cout << "Available rooms: ";
    for (int rn : available) cout << rn << " ";
    cout << "\n";

    int roomNo = util::getInt("Select Room No: ", 1, 9999);
    auto it = rooms_.find(roomNo);
    if (it == rooms_.end()) { cout << "Room not found.\n"; return; }
    if (it->second.occupied) { cout << "Room already occupied.\n"; return; }

    cout << "Room services:\n";
    int win = util::getInt("Window? (1=Yes, 0=No): ", 0, 1);
    int ac  = util::getInt("AC? (1=Yes, 0=No): ", 0, 1);
    cout << "Bed Type:\n1. Single\n2. Twin\n3. Double\n";
    int bt  = util::getInt("Choose: ", 1, 3);

    it->second.window = (win == 1);
    it->second.ac     = (ac == 1);
    it->second.bed    = (bt == 1 ? BedType::Single : bt == 2 ? BedType::Twin : BedType::Double);

    int price = 2000;
    if (it->second.ac) price += 1000;
    if (it->second.window) price += 300;
    if (it->second.bed == BedType::Twin) price += 500;
    if (it->second.bed == BedType::Double) price += 900;
    it->second.pricePerNight = price;

    it->second.occupied = true;
    it->second.occupiedByCustomerId = cid;

    Customer c;
    c.id = cid;
    c.name = name;
    c.phone = phone;
    c.roomNo = roomNo;
    c.roomCharge = price;

    // Save in DB
    if (!dbInsertCustomerCheckedIn(c)) {
        cout << "DB error: customer not saved.\n";
        it->second.occupied = false;
        it->second.occupiedByCustomerId = -1;
        return;
    }
    dbUpdateRoom(it->second);

    // cache
    customers_[cid] = c;
    rooms_[roomNo] = it->second;

    cout << "Booked successfully!\n";
    cout << "Room " << roomNo << " | Price/Night: Rs " << price
         << " | " << (it->second.window ? "Window" : "Non-Window")
         << " | " << (it->second.ac ? "AC" : "Non-AC")
         << " | Bed: " << bedToString(it->second.bed) << "\n";
}

void HotelSystem::viewRooms() {
    cout << "\n--- Rooms ---\n";
    if (rooms_.empty()) { cout << "No rooms.\n"; return; }

    vector<int> keys;
    for (auto &kv : rooms_) keys.push_back(kv.first);
    sort(keys.begin(), keys.end());

    for (int rn : keys) {
        const Room &r = rooms_.at(rn);
        cout << "Room " << r.number
             << " | " << (r.window ? "Window" : "Non-Window")
             << " | " << (r.ac ? "AC" : "Non-AC")
             << " | Bed: " << bedToString(r.bed)
             << " | Price/Night: Rs " << r.pricePerNight
             << " | Status: " << (r.occupied ? "Occupied" : "Available");
        if (r.occupied) cout << " (CustomerID " << r.occupiedByCustomerId << ")";
        cout << "\n";
    }
}

void HotelSystem::viewCustomers() {
    cout << "\n--- Active Customers (Checked-in) ---\n";
    if (customers_.empty()) { cout << "No active customers.\n"; return; }

    vector<int> ids;
    for (auto &kv : customers_) ids.push_back(kv.first);
    sort(ids.begin(), ids.end());

    for (int id : ids) {
        const Customer &c = customers_.at(id);
        cout << "ID: " << c.id
             << " | Name: " << c.name
             << " | Phone: " << c.phone
             << " | Room: " << c.roomNo
             << " | Room Charge/Night: Rs " << c.roomCharge << "\n";
    }
}
